public class ArvoreBinaria {
    private No raiz;

    public ArvoreBinaria() {
        this.raiz = null;
    }

    public void inserir(int valor) {
        No novoNo = new No(valor);
        if (this.raiz == null) {
            this.raiz = novoNo;
        } else {
            No noAtual = this.raiz;
            No noPai = null;
            while (noAtual != null) {
                noPai = noAtual;
                if (novoNo.getValor() < noAtual.getValor()) {
                    noAtual = noAtual.getEsq();
                } else  {
                    noAtual = noAtual.getDir();
                }
            }
            if (novoNo.getValor() < noPai.getValor()) {
                noPai.setEsq(novoNo);
            }
            if (novoNo.getValor() > noPai.getValor()) {
                noPai.setDir(novoNo);
            }
        }
    }

    public void preOrdem() {
        preOrdem2(this.raiz);
        System.out.println("");
    }

    private void preOrdem2(No no) {
        if (no == null) {
            return;
        }
        System.out.print(no.getValor() + " ");
        preOrdem2(no.getEsq());
        preOrdem2(no.getDir());
    }

    public void emOrdem() {
        emOrdem2(this.raiz);
        System.out.println("");
    }

    private void emOrdem2(No no) {
        if (no == null) {
            return;
        }
        emOrdem2(no.getEsq());
        System.out.print(no.getValor() + " ");
        emOrdem2(no.getDir());
    }

    public void posOrdem() {
        posOrdem2(this.raiz);
        System.out.println("");
    }

    private void posOrdem2(No no) {
        if (no == null) {
            return;
        }
        preOrdem2(no.getEsq());
        preOrdem2(no.getDir());
        System.out.print(no.getValor() + " ");
    }

    public void remover(int valor) {
        if (noExistente(valor)) {
            buscarNo(this.raiz, valor);
        } else {
            System.out.println("Este nó não existe!");
        }
    }

    private boolean noExistente(int valor) {
        No noAtual = this.raiz;
        while (noAtual.getValor() != valor) {
            if (noAtual.getValor() > valor) {
                if (noAtual.getEsq() == null) {
                    return false;
                } else {
                    noAtual = noAtual.getEsq();
                }
            }
            if (noAtual.getValor() < valor) {
                if (noAtual.getDir() == null) {
                    return false;
                } else {
                    noAtual = noAtual.getDir();
                }
            }
        }
        return true;
    }

    private void buscarNo(No no, int valor) {
        if (no.getEsq() != null) {
            if (no.getEsq().getValor() == valor) {
                remover2(no, 'e');
            } else {
                if (no.getEsq() != null) {
                    buscarNo(no.getEsq(), valor);
                }
            }
        }
        if (no.getDir() != null) {
            if (no.getDir().getValor() == valor) {
                remover2(no, 'd');
            } else {
                if (no.getDir() != null) {
                    buscarNo(no.getDir(), valor);
                }
            }
        }
    }

    private void remover2(No no, char direcao) {
        boolean noRemovido = false;
        if (direcao == 'e') {
            if (no.getEsq().getEsq() == null && no.getEsq().getDir() == null && !noRemovido) {
                no.setEsq(null);
                noRemovido = true;
            }
            if (no.getEsq().getEsq() != null && no.getEsq().getDir() == null && !noRemovido) {
                no.setEsq(no.getEsq().getEsq());
                noRemovido = true;
            }
            if (no.getEsq().getEsq() == null && no.getEsq().getDir() != null && !noRemovido) {
                no.setEsq(no.getEsq().getDir());
                noRemovido = true;
            }
            if (no.getEsq().getEsq() != null && no.getEsq().getDir() != null && !noRemovido) {
                No novoNo = no.getEsq().getDir();
                No novoNoPai = null;
                while (novoNo.getEsq() != null) {
                    novoNoPai = novoNo;
                    novoNo = novoNo.getEsq();
                }
                novoNoPai.setEsq(null);
                novoNo.setEsq(no.getEsq());
                novoNo.setDir(no.getDir());
                no.setEsq(novoNo);
                noRemovido = true;
            }
        }
        if (direcao == 'd') {
            if (no.getDir().getEsq() == null && no.getDir().getDir() == null && !noRemovido) {
                no.setDir(null);
                noRemovido = true;
            }
            if (no.getDir().getEsq() != null && no.getDir().getDir() == null && !noRemovido) {
                no.setDir(no.getDir().getEsq());
                noRemovido = true;
            }
            if (no.getDir().getEsq() == null && no.getDir().getDir() != null && !noRemovido) {
                no.setDir(no.getDir().getDir());
                noRemovido = true;
            }
            if (no.getDir().getEsq() != null && no.getDir().getDir() != null && !noRemovido) {
                No novoNo = no.getDir().getDir();
                No novoNoPai = null;
                while (novoNo.getEsq() != null) {
                    novoNoPai = novoNo;
                    novoNo = novoNo.getEsq();
                }
                novoNoPai.setEsq(null);
                novoNo.setEsq(no.getEsq());
                novoNo.setDir(no.getDir());
                no.setDir(novoNo);
                noRemovido = true;
            }
        }
    }

    public No getRaiz() {
        return this.raiz;
    }
}
