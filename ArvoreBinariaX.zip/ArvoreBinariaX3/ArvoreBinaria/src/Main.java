import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        ArvoreBinaria arvoreBinaria = new ArvoreBinaria();

        int opcao = 0;
        while (opcao != 6) {
            System.out.print("1 - Inserir Nó \n" +
                            "2 - Remover Nó \n" +
                            "3 - Travessia em pré-ordem \n" +
                            "4 - Travessia em em-ordem \n" +
                            "5 - Travessia em pós-ordem \n" +
                            "6 - Encerrar execução \n" +
                            "Opção: ");
            opcao = scanner.nextInt();
            while (opcao < 1 || opcao > 6) {
                System.out.print("Opção inválida! Opção: ");
                opcao = scanner.nextInt();
            }

            switch (opcao) {
                case 1:
                    System.out.print("Valor: ");
                    int valor = scanner.nextInt();
                    arvoreBinaria.inserir(valor);
                    break;
                case 2:
                    System.out.print("Valor: ");
                    int valor2 = scanner.nextInt();
                    arvoreBinaria.remover(valor2);
                    break;
                case 3:
                    arvoreBinaria.preOrdem();
                    break;
                case 4:
                    arvoreBinaria.emOrdem();
                    break;
                case 5:
                    arvoreBinaria.posOrdem();
                    break;
                case 6:
                    break;
            }
        }
    }
}
