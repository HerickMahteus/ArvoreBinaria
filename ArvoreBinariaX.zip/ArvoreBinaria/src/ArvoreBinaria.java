public class ArvoreBinaria {
    private No raiz;

    public ArvoreBinaria() {
        this.raiz = null;
    }

    public void inserir(int valor) {
        No novoNo = new No(valor);
        if (this.raiz == null) {
            this.raiz = novoNo;
        } else {
            No noAtual = this.raiz;
            No noPai = null;
            while (noAtual != null) {
                noPai = noAtual;
                if (novoNo.getValor() < noAtual.getValor()) {
                    noAtual = noAtual.getEsq();
                } else {
                    noAtual = noAtual.getDir();
                }
            }
            if (novoNo.getValor() < noPai.getValor()) {
                noPai.setEsq(novoNo);
            } else {
                noPai.setDir(novoNo);
            }
        }
    }

    public void preOrdem() {
        preOrdem2(this.raiz);
        System.out.println("");
    }

    private void preOrdem2(No no) {
        if (no == null) {
            return;
        }
        System.out.print(no.getValor() + " ");
        preOrdem2(no.getEsq());
        preOrdem2(no.getDir());
    }

    public void emOrdem() {
        emOrdem2(this.raiz);
        System.out.println("");
    }

    private void emOrdem2(No no) {
        if (no == null) {
            return;
        }
        emOrdem2(no.getEsq());
        System.out.print(no.getValor() + " ");
        emOrdem2(no.getDir());
    }

    public void posOrdem() {
        posOrdem2(this.raiz);
        System.out.println("");
    }

    private void posOrdem2(No no) {
        if (no == null) {
            return;
        }
        posOrdem2(no.getEsq());
        posOrdem2(no.getDir());
        System.out.print(no.getValor() + " ");
    }

    public void remover(int valor) {
        this.raiz = remover2(this.raiz, valor);
    }

    private No remover2(No no, int valor) {
        if (no == null) {
            return null;
        }

        if (valor < no.getValor()) {
            no.setEsq(remover2(no.getEsq(), valor));
        } else if (valor > no.getValor()) {
            no.setDir(remover2(no.getDir(), valor));
        } else {
            // Nó com o valor a ser removido encontrado

            // Caso 1: Nó sem filhos
            if (no.getEsq() == null && no.getDir() == null) {
                return null;
            }

            // Caso 2: Nó com um filho
            if (no.getEsq() == null) {
                return no.getDir();
            }
            if (no.getDir() == null) {
                return no.getEsq();
            }

            // Caso 3: Nó com dois filhos
            No menorNoDir = encontrarMenorNo(no.getDir());
            no.setValor(menorNoDir.getValor());
            no.setDir(remover2(no.getDir(), menorNoDir.getValor()));
        }

        return no;
    }

    private No encontrarMenorNo(No no) {
        while (no.getEsq() != null) {
            no = no.getEsq();
        }
        return no;
    }

    public No getRaiz() {
        return this.raiz;
    }
}
