class Node {
    int key; //Este é o valor armazenado no nó.
    Node left, right; //Referências para os filhos esquerdo e direito do nó

    public Node(int item) { //Referências para os filhos esquerdo e direito do nó
        key = item;
        left = right = null;
    }
}

class BinarySearchTree { //Referência para a raiz da árvore.
    Node root;

    BinarySearchTree() { //Inicializa a árvore com a raiz como null.
        root = null; 
    }

    // Método para inserir um novo nó com a chave especificada
    void insert(int key) {
        root = insertRec(root, key);
    }

    // Método recursivo para inserir um novo nó na árvore
    Node insertRec(Node root, int key) {
        // Se a árvore estiver vazia, retornar um novo nó
        if (root == null) {
            root = new Node(key);
            return root;
        }

        // Caso contrário, percorrer a árvore recursivamente
        if (key < root.key) {
            root.left = insertRec(root.left, key); //Se a chave é menor que a chave do nó atual (key < root.key), insere na subárvore esquerda.
        } else if (key > root.key) {
            root.right = insertRec(root.right, key); //Se a chave é maior que a chave do nó atual (key > root.key), insere na subárvore direita.
        }

        // Retornar o nó (inalterado)
        return root;
    }

    // Método para realizar a travessia em ordem e imprimir a árvore
    void inorder() {
        inorderRec(root);
    }

    // Método recursivo para realizar a travessia em ordem
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.key + " ");
            inorderRec(root.right);
        }
    }

    void remove(int key) { removeRec(root, key); }

    Node removeRec(Node root, int key) {
        if (root == null) {
            return root;
        }

        if (key < root.key) {
            root.left = removeRec(root.left, key);
        } else if (key > root.key) {
            root.right = removeRec(root.right, key);
        } else {
            // Nó encontrado, agora vamos deletá-lo

            // Nó com apenas um filho ou nenhum filho
            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;

            // Nó com dois filhos: Obter o sucessor inorder (menor na subárvore direita)
            root.key = minValue(root.right);

            // Deletar o sucessor inorder
            root.right = removeRec(root.right, root.key);
        }

        return root;
    }

    int minValue(Node root) {
        int minv = root.key;
        while (root.left != null) {
            minv = root.left.key;
            root = root.left;
        }
        return minv;
    }
}

public class BinarySearchTreeDemo {
    public static void main(String[] args) {
        BinarySearchTree tree = new BinarySearchTree();

        // Inserir nós na árvore
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        // Imprimir a árvore em ordem
        System.out.println("Travessia em ordem da árvore binária:");
        tree.inorder();

        tree.remove(30);

        System.out.println("\n");
        System.out.println("Travessia em ordem da árvore binária:");
        tree.inorder();
    }
}
